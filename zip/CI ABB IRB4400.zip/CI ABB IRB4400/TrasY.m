function [Rx]=TrasY(d)
Rx=[1 0 0 0;
    0 1 0 d;
    0 0 1 0;
    0 0 0 1];
end